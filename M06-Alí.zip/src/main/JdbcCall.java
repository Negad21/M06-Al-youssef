package main;
import service.Service;

public class JdbcCall {

	public static void main(String[] args) {
		(new Service()).init();
	}

}
